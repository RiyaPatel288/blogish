import { FaInstagram } from "react-icons/fa";
const Instagramcom = () => {
    return (
        <>
            <FaInstagram style={{marginTop:'20px',marginRight:'10px'}}/>
        </>
    )
}
export default Instagramcom;
