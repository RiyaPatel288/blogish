import { FaTwitter } from "react-icons/fa";
const Twittercom = () => {
    return (
        <>
            <FaTwitter style={{marginTop:'20px',marginRight:'10px'}}/>
        </>
    )
}
export default Twittercom;
